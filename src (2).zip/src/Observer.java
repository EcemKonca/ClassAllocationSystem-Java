import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

// Subject
interface ClassroomSubject {
    void attach(ClassroomObserver observer);

    void deAttach(ClassroomObserver observer);

    void notifyObservers(DayOfWeek testDay, LocalDateTime startTime, LocalDateTime endTime);
}

// Observer
interface ClassroomObserver {
    void update(Classroom classroom, DayOfWeek testDay, LocalDateTime startTime, LocalDateTime endTime);
}

// Concrete observer
class ClassroomScheduler implements ClassroomObserver {

    private final ClassroomAdmin classroomAdmin;

    public ClassroomScheduler(ClassroomAdmin classroomAdmin) {
        this.classroomAdmin = classroomAdmin;
    }

    public void markClassroomsAsAvailable(CampusComponent rootComponent, DayOfWeek testDays, LocalDateTime startTime, LocalDateTime endTime) {
        List<Classroom> classrooms = extractClassrooms(rootComponent);
        for (Classroom classroom : classrooms) {
            if (!classroom.isAvailable(testDays, startTime, endTime)) {
                MarkClassroomAvailabilityClassroomCommand command = new MarkClassroomAvailabilityClassroomCommand(classroom, testDays,startTime,endTime);
                classroomAdmin.unExecuteAvailabilityCommand(command, testDays, startTime, endTime);
            }
        }
    }

    public void markClassroomsAsUnavailable(CampusComponent rootComponent, DayOfWeek testDay, LocalDateTime startTime, LocalDateTime endTime) {
        List<Classroom> classrooms = extractClassrooms(rootComponent);
        for (Classroom classroom : classrooms) {
            if (classroom.isAvailable(testDay, startTime, endTime)) {
                MarkClassroomAvailabilityClassroomCommand command = new MarkClassroomAvailabilityClassroomCommand(classroom, testDay,startTime,endTime);
                classroomAdmin.executeAvailabilityCommand(command, testDay, startTime, endTime);
            }
        }
    }

    private List<Classroom> extractClassrooms(CampusComponent rootComponent) {
        ClassroomIterator classroomIterator = new ConcreteClassroomIterator(rootComponent);
        List<Classroom> classrooms = new ArrayList<>();
        while (classroomIterator.hasNext()) {
            Classroom classroom = classroomIterator.next();
            classrooms.add(classroom);
        }
        return classrooms;
    }

    @Override
    public void update(Classroom classroom, DayOfWeek testDay, LocalDateTime startTime, LocalDateTime endTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

        System.out.println("Classroom " + classroom.getName() + " has been updated. Availability: " + classroom.isAvailable(testDay, startTime, endTime) + " on " + testDay.toString().toLowerCase() + " at " + startTime.format(formatter) + "-" + endTime.format(formatter));
    }
}
// Concrete Subject -- Classroom